

    <script src="assets/js/bootstrap5.min.js"></script>
    <script src="assets/js/jquery.js"></script>
    <script
        src="https://cdnjs.cloudflare.com/ajax/libs/web3/4.1.1/web3.min.js"
        integrity="sha512-C/TYwf93EQ6sPW4g3F9axNydQuQrAQCTOR1Gz65YK96MwrZ0KDn3qjNMAlXLYyjm84JELTYHinAfvUjbNC4fuQ=="
        crossorigin="anonymous"
        referrerpolicy="no-referrer"
        ></script>
        <script src="assets/js/blockchain.js"></script>
</body> 
</html>