<pre>
<?php 
print_r($_POST);
print_r($_SERVER);
print_r($_REQUEST);
?>
</pre>